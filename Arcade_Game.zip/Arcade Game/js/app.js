// Enemies our player must avoid
var Enemy = function() {
    // Variables applied to each of our instances go here,
    // we've provided one for you to get started

    // The image/sprite for our enemies, this uses
    // a helper we've provided to easily load images
    this.sprite = 'images/enemy-bug.png';
    this.gridRow=0;
    this.gridIndex=0;
    this.currentGrid=grids[this.gridRow*9 + this.gridIndex];
    this.x=0-100;
    this.y=470-350*Math.random();
    this.directionToMove="";
    this.speed=Math.random()*200+70;
    this.collapsed=false;
    this.trapped=false;
    this.trappingRock=null;
    this.explodingCompleted=false;
};

Enemy.prototype.isTrapped=function(){

   setTimeout(()=>{
       if(this.trappingRock){
           obstacles.splice(obstacles.indexOf(this.trappingRock),1);
           this.trappingRock.parentGrid.available=true;
           this.trappingRock=null;
       }
   },500);
}
// Update the enemy's position, required method for game
// Parameter: dt, a time delta between ticks
Enemy.prototype.update = function(dt) {
    // You should multiply any movement by the dt parameter
    // which will ensure the game runs at the same speed for
    // all computers.
    if(!this.collapsed)
    this.x+=this.speed*dt;
    
    this.findCurrentRow=()=>{
        //finding Current Row:-
      switch(true){
        case (this.y+145 >=grids[0].y+50 && this.y+145<grids[0].y+50+grids[0].height):
            this.gridRow=0;
            break;
        case (this.y+145 >=grids[9].y+50 && this.y+145<grids[9].y+50+grids[9].height):
            this.gridRow=1;
            break;
        case (this.y+145 >=grids[18].y+50 && this.y+145<grids[18].y+50+grids[18].height):
            this.gridRow=2;
            break;
        case (this.y+145 >=grids[27].y+50 && this.y+145<grids[27].y+50+grids[27].height):
            this.gridRow=3;
            break;
        case (this.y+145 >=grids[36].y+50 && this.y+145<grids[36].y+50+grids[36].height):
            this.gridRow=4;
       }
    }


   //finding Our Current Grid:-
   this.findCurrentGrid=()=>{
       this.findCurrentRow();
       if(this.x>=this.currentGrid.x+this.currentGrid.width){
        this.gridIndex+=1;
        if(this.gridIndex>8) return;
       }

       else if(this.x<this.currentGrid.x){
           if(this.gridIndex===0) return;
           if(this.x+100<=this.currentGrid.x)
           this.gridIndex-=1;
       }
       this.currentGrid=grids[this.gridRow*9+this.gridIndex];     
   }

   this.selectDirectionAndMove=()=>{
       //Checking if we can move downWard:-
       let downDirCheck=this.gridRow,downDirCounter=this.gridRow;
       if(this.x>grids[0].x){
          while(downDirCounter<4){
              if(grids[downDirCounter*9+this.gridIndex+10].child===Obstacles){
                  if(downDirCounter<3){
                      if(grids[(downDirCounter+2)*9+this.gridIndex].child===Obstacles)
                      downDirCheck=4;
                  }
                  downDirCheck++;
              }
              downDirCounter++;
          }
       }
       else if(this.x<=grids[0].x){
           while(downDirCounter<=4){
               if(grids[(downDirCounter+1)*9] && grids[(downDirCounter+1)*9].child===Obstacles){
                   downDirCheck++;
               }
               downDirCounter++;
           }
       }

       //Checking If we can move Upward:-
       let upDirCheck=this.gridRow,upDirCounter=this.gridRow;
       if(this.x>grids[0].x){
           while(upDirCounter>0){
               if(grids[upDirCounter*9+this.gridIndex-8].child===Obstacles){
                  if(upDirCounter>1){
                      if(grids[(upDirCounter-1)*9+this.gridIndex-9].child===Obstacles)
                      upDirCheck=0;
                  }
                  upDirCheck--;
               }
               upDirCounter--;
           }
       }

       else if(this.x<=grids[0].x){
           while(upDirCounter>0){
               if(grids[upDirCounter*9-9].child===Obstacles){
                   upDirCheck--;
               }
               upDirCounter--;
           }
       } 

      //Where To Move The Enemy?
     if(this.gridRow<4){
         if(this.x>grids[0].x){
          if(grids[grids.indexOf(this.currentGrid)+9] && grids[grids.indexOf(this.currentGrid)+9].child!==Obstacles){
              if(downDirCheck<4){
                  this.y+=this.speed*dt;
                  this.trapped=false;
              }
              
              else{
                  if(grids[grids.indexOf(this.currentGrid)-9] && grids[grids.indexOf(this.currentGrid)-9].child!==Obstacles && upDirCheck>0){
                      this.y-=this.speed*dt;
                      this.trapped=false;
                  }
                  else{
                    this.trapped=true;
                  }
              }
          }
          else if(grids[grids.indexOf(this.currentGrid)+9].child===Obstacles){
              if(grids[grids.indexOf(this.currentGrid)-9] && grids[grids.indexOf(this.currentGrid)-9].child!==Obstacles && upDirCheck>0){
                 
                  this.y-=this.speed*dt;
                  this.trapped=false;
              }
              else{
                this.trapped=true;
                }
              
             }

         }

         else if(this.x<=grids[0].x){
             if(downDirCheck<4){
                this.y+=this.speed*dt;
                this.trapped=false;
             }
             else{
                 if(upDirCheck>0){
                    this.y-=this.speed*dt;
                    this.trapped=false;
                 }
                 else{
                    this.trapped=true;
                 }
             }
         }
     }

     else if(this.gridRow<=4){
         if(this.x>grids[0].x){
          if(grids[grids.indexOf(this.currentGrid)-9] && grids[grids.indexOf(this.currentGrid)-9].child!==Obstacles && upDirCheck>0){
              this.y-=this.speed*dt;
              this.trapped=false;
          }
          else{
            this.trapped=true;
           }
         } 

         else if(this.x<grids[0].x){
          if(downDirCheck<4){
            this.y+=this.speed*dt;
            this.trapped=false;
          }
          else{
              if(upDirCheck>0){
                this.y-=this.speed*dt;
                this.trapped=false;
              }
              else{
                this.trapped=true;
              }
           }
        }
     }
   }

   if(!this.collapsed && !this.trapped)
   this.findCurrentGrid();

   this.checkForCollision=()=>{
       this.collapsed=false;
       this.trapped=false;
       //Checking For Collision Of The Player with the rocks:-
       obstacles.forEach((obstacle)=>{
        if((!this.trapped && Math.floor(this.x+100)>=Math.floor(obstacle.x+15) && Math.floor(this.x)<=Math.floor(obstacle.x+15)) || (this.trapped && Math.floor(this.x)<=Math.floor(obstacle.x+82) && Math.floor(this.x+100)>=Math.floor(obstacle.x+15))){
            if(Math.floor(obstacle.y-70)<=Math.floor(this.y) && Math.floor(obstacle.y)>=Math.floor(this.y-60)){
                this.collapsed=true;
                this.selectDirectionAndMove();
                if(this.trapped){
                    this.trappingRock=obstacle;
                    obstacle.sprite='images/explosion.png';
                    this.isTrapped();
                }
            }
        }
     })
   }

   
    //checking For Collision Of the player with the enemy:-
    for(let enemy of allEnemies){
        if(Math.floor(player.x)>=Math.floor(this.x-45) && Math.floor(player.x)<=Math.floor(this.x+70)){
            if(Math.floor(player.y-70)<=Math.floor(this.y) && Math.floor(player.y)>=Math.floor(this.y-60)){
                scores.score-=10;
                player.x=150;
                player.y=33;
            }
        }

        this.checkForCollision();
        
        //Removing Monsters that left the field from the array:-
        if(enemy.x>grids[44].x+grids[44].width)
         allEnemies.splice(allEnemies.indexOf(enemy),1);
     }
}


// Draw the enemy on the screen, required method for game
Enemy.prototype.render = function() {
    ctx.drawImage(Resources.get(this.sprite), this.x, this.y);
};

// Now write your own player class
// This class requires an update(), render() and
// a handleInput() method.

class Player{
    constructor(){
        this.sprite='images/char-boy.png';
        this.x=150;
        this.y=33;
        this.collisionWithObstacle=false;
        this.coordinatesHasChanged=false;
    }

    render(){
        ctx.drawImage(Resources.get(this.sprite), this.x, this.y);
    }

    update(){

    }

    isCollision(){
        this.collisionWithObstacle=false;
         //Checking for Collision of the player with the rocks:-
        for(let obstacle of obstacles){
            if(Math.floor(this.x)>=Math.floor(obstacle.x-45) && Math.floor(this.x)<=Math.floor(obstacle.x+70)){
                if(Math.floor(this.y-70)<=Math.floor(obstacle.y) && Math.floor(this.y)>=Math.floor(obstacle.y-60)){
                    this.collisionWithObstacle=true;
                }
            }
        }
    }

    checkForCollision(){
        this.isCollision();
        if(this.collisionWithObstacle){
              this.collisionWithObstacle=false;
              return true;
         }
    }

    handleInput(obj){
        //Handling Keyborad Events and preventing the player from going out of the screen:-
        switch (obj){
            case 'left':
                if(this.x<0) return;
                this.x-=30;
                if(this.checkForCollision()) this.x+=30;
                break;
            case 'right':
                if(this.x>=820) return;
                this.x+=30;
                if(this.checkForCollision()) this.x-=30;
                break;
            case 'up':
                if(this.y<=0) return;
                this.y-=30;
                if(this.checkForCollision()) this.y+=30;
                break;
            case 'down':
                if(this.y>=490) {
                    this.y=33;
                    scores.score+=10;
                }
                this.y+=30;
                if(this.checkForCollision()) this.y-=30;
                break;
            default:
               return;

        }
        
    }
}

//Selection For Character:-

class CharacterSelector{
    constructor(){
        this.sleekBars='images/sleekBars.png';
        this.selector='images/selector.png';
        this.sprites=['images/char-boy.png','images/char-cat-girl.png','images/char-horn-girl.png','images/char-pink-girl.png','images/char-princess-girl.png'];
        this.yCoords=[50,180,300,410,530];
        this.yCoordsCounter=0;
        this.gameReadyToStart=false;
        this.currentlySelectedCharacter=this.sprites[0];
    }
    render(){
           //Clear The Canvas Before Drawing anyThing:-
           ctx.clearRect(0,0,myCanvas.width,myCanvas.height);

           //Creaing a gradient background:-
           let myGradient=ctx.createLinearGradient(0,0,myCanvas.width,0);
           myGradient.addColorStop(0,'black');
           myGradient.addColorStop(0.2,'orange');
           myGradient.addColorStop(1,'white');
           ctx.fillStyle=myGradient;
           ctx.fillRect(0,0,myCanvas.width,myCanvas.height); 

           //Printing The Text on The welcome screen:-
           ctx.font='bolder 40px Arial';
           ctx.fillStyle='grey';
           ctx.fillText('Welcome to the classic Arcade game',170,50);
           ctx.font='bold 15px Arial';
           ctx.fillText(`Please use The 'Up' and 'Down' Arrows`,600,200);
           ctx.fillText('To Select A Character to play with.',600,250);
           ctx.fillText(`Then Press The 'Enter' Button to start!`,600,300);
           ctx.font='bolder 40px Arial';
           ctx.fillStyle='grey';
           ctx.fillText('Enjoy You Time!!',600,400);


           //The List of Characters to select from:-
           ctx.drawImage(Resources.get(this.sleekBars), 200,100);
           //The Selector:-
           ctx.drawImage(Resources.get(this.selector),330,this.yCoords[this.yCoordsCounter]-30);
           for(let counter=0;counter<this.sprites.length;counter++){
               ctx.drawImage(Resources.get(this.sprites[counter]),330,this.yCoords[counter]);
           }
    }

    //Changing The Coordinates of the selection box:-
    update(key){

        if(key==='down'){
            this.yCoordsCounter+=1;
            if(this.yCoordsCounter>4)
            this.yCoordsCounter=0;
        }

        else if(key==='up'){
            this.yCoordsCounter-=1;
            if(this.yCoordsCounter<0)
            this.yCoordsCounter=4;
        }
        this.currentlySelectedCharacter=this.sprites[this.yCoordsCounter];
        
    }

    //Handling input with the character Selector:-
    handleInput(key){
        if(key==='up' || key==='down')
        this.update(key);
        else if(key==='enter'){
            player.sprite=this.currentlySelectedCharacter;
            this.gameReadyToStart=true;
        }     
    }
}

//The Game Over Screen:-

class GameOverScreen{
    render(){

           ctx.clearRect(0,0,myCanvas.width,myCanvas.height);
           //Creaing a gradient background:-
           let myGradient=ctx.createLinearGradient(0,0,myCanvas.width,0);
           myGradient.addColorStop(0,'black');
           myGradient.addColorStop(0.2,'orange');
           myGradient.addColorStop(1,'white');
           ctx.fillStyle=myGradient;
           ctx.fillRect(0,0,myCanvas.width,myCanvas.height); 
           ctx.font='bolder 45px Arial';
           ctx.fillStyle='Black';
           ctx.fillText('Game Over',270,50);
           ctx.font='bold 35px Arial';
           ctx.fillText(`We Are Sorry, Your Game Ends Here!...`,170,200);
           ctx.fillText(`Highest score you had was ${scores.highestScore}`,170,250);
           ctx.fillText(`Hope You Enjoyed Our Classic Arcade Game!`,160,300);
           ctx.fillText(`Hope To See You Again on A New Challenge!`,170,450);
    }
}

let gameOver=new GameOverScreen();

class CollectableItems{
    constructor(x,y){
        this.x=x;
        this.y=y;
        this.sprites=['images/Heart.png','images/Blue.png','images/Green.png','images/Orange.png','images/bomb_circle.png','images/Key.png'];
        this.index=Math.round(Math.random()*(this.sprites.length-1));
        this.sprite=this.sprites[this.index];
        this.bonus=0;
        this.oldItem="";
         //Selecting The Bonus Based on What Item was taken:-
         switch(this.sprite){
            case 'images/Heart.png':
                this.bonus=5;
                break;
            case 'images/Blue.png':
                this.bonus=7;
                break;
            case 'images/Orange.png':
                this.bonus=8;
                break;
            case 'images/Green.png':
                this.bonus=6;
                break;
            case 'images/bomb_circle.png':
                this.bonus=-6;
                break;
            case 'images/Key.png':
                this.bonus=10;
        }
    }

    render(){
        ctx.drawImage(Resources.get(this.sprite),this.x,this.y);
    }

    bombExploded(){
        if(this.oldItem==="Bomb"){
            setTimeout(()=>{
               allItems.splice(allItems.indexOf(this),1);
               this.oldItem="";
            },200);
        }
    }

    update(){

        //Checking for collision  with the player:- 
        if(player.x+70>=this.x && player.x<this.x+15){
            if(player.y+115>=this.y && player.y<this.y){
                if(this.sprite==='images/bomb_circle.png'){
                    this.oldItem="Bomb";
                    player.x=155;
                    player.y=33;
                    this.sprite='images/shot.png';
                    this.bombExploded();
                }
                else
                allItems.splice(allItems.indexOf(this),1);
                scores.score+=this.bonus;
            }
           
        }

    }
}

//Creating The Rocks:-
class Obstacles{
    constructor(x,y){
        this.sprite='images/Rock.png';
        this.x=x;
        this.y=y; 
        this.parentGrid=null;    
    }
    render(){
        ctx.drawImage(Resources.get(this.sprite),this.x,this.y);
    }
}

//Dividing The playing field into multiple grids to install the rocks and the collectable items:-
class Grids{
    constructor(x,y){
        this.x=x;
        this.y=y;
        this.available=true;
        this.child=null;
        this.width=100;
        this.height=121;
    }
}

//Collecting The Grids into an array for use:-
let grids=[];
let y=140;
for (let i=0;i<5;i++){
    for(let j=0;j<9;j++){
        let newGrid=new Grids(j*100,y)
        grids.push(newGrid);
    }
    y+=80;
}
//Selecting a grid randomly from The array and see if it's available to put the Rocks on it:-
let obstacles=[];
let placingRocks= ()=>{
    let selector=Math.round(Math.random()*(grids.length-1))
    if(grids[selector].available===false)
    placingRocks();
    let newObstacle=new Obstacles(grids[selector].x,grids[selector].y);
    newObstacle.parentGrid=grids[selector];
    obstacles.push(newObstacle);
    grids[selector].available=false;
    grids[selector].child=Obstacles;
}

for(let i=0;i<10;i++)
placingRocks();

let characterSelector=new CharacterSelector();

//Creating Instances Of Player and Enemies:-
let player=new Player();

let allEnemies=[];

//creating Enemies:-
    setInterval(()=>{
        if(!pause){
            let newEnemy=new Enemy(); 
            allEnemies.push(newEnemy); 
        }
    },1800);

//Creating Items To Collect:-
let allItems=[];

this.createCollectables=()=>{
    if(!pause){
        let selector=Math.round(Math.random()*(grids.length-1));
        if(grids[selector] && grids[selector].child===null){
        let newItem=new CollectableItems(grids[selector].x+20,grids[selector].y+60);
        grids[selector].child=newItem;
        allItems.push(newItem);
       }
    }   
}

setInterval(this.createCollectables,Math.random()*7000);


class Scores{
    constructor(){
        this.score=0;
        this.highestScore=0;
    }

    render(){
        ctx.font='bolder 40px Arial';
        ctx.fillStyle='red'
        ctx.fillText(this.score,800,100);
        if(this.score>this.highestScore)
        this.highestScore=this.score;
    }
}

let scores=new Scores;


// This listens for key presses and sends the keys to the
// Player.handleInput() method or characterSelector.handleInput() method.
document.addEventListener('keyup', function(e) {
    var allowedKeys = {
        37: 'left',
        38: 'up',
        39: 'right',
        40: 'down',
        13: 'enter'
    };
    if(characterSelector.gameReadyToStart)
    player.handleInput(allowedKeys[e.keyCode]);
    else
    characterSelector.handleInput(allowedKeys[e.keyCode]);
});

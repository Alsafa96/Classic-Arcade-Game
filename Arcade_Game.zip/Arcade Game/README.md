# Classic Arcade Game Clone Project

## Welcome To Our Classic Arcade Game:##

## How To Run The Game:-##

To Run The Game Open The **index** file , You see The Starting Screen...
Use The **Up** and **Down** Keys to Select character Then Press **Enter** To Start The Game.

## How To Play The Game:-##
Use The **UP** and **Down** and **Right** and **Left** directions to Move The Player , You should Avoid Collision With The Enemy.
Try To Reach The Water, Upon Arrival you get _10_ Scores and retrun to The Beginning of the Game to play again.

**Collapsing With The Enemy causes you to loss _10_ Scores**

**You can't walk through The Rocks**

**If The enemy reaches a Rock, he will avoid it, if he finds it a dead end, he will explode it!**

You Have Collectable Items To Collect During your way:-

**Heart:-** Gives You 5 Scores.

**Blue Jewelery:-** Gives You 7 Scores.

**Green Jewelery:-** Gives You 6 Scores.

**Orange Jewelery:-** Gives You 8 Scores.

**The Key:-** Gives You 10 Scores.

**The Bomb:-** Causes You to return to The Begining of your way and loss 6 Scores.

When You Loss all your scores You'll Get The Game Over Screen.

**Enjoy Your Time!**